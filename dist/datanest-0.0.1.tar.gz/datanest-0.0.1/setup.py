from setuptools import setup, find_packages

setup(
    name='datanest',
    version='0.0.1',
    description='A group of Datasets for you project',
    author='Ethan Barr',
    author_email='ethanwbarr07@gmail.com',
    url='https://github.com/Ethan-Barr/Datanest',
    packages=find_packages(),
    install_requires=[
        # Add dependencies
    ],
)